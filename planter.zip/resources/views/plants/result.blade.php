<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plant Identification Result - Plant Identifier</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
        }
        .gradient-bg {
            background: linear-gradient(135deg, #4ade80 0%, #22c55e 100%);
        }
        .animate-fade-in {
            animation: fadeIn 0.5s ease-in;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navigation -->
    <nav class="gradient-bg shadow-lg">
        <div class="container mx-auto px-4 py-3">
            <div class="flex justify-between items-center">
                <a href="/" class="flex items-center space-x-2">
                    <svg class="w-8 h-8 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M12 2v8"/>
                        <path d="M5 5c1.5 3 4.5 5 7 5s5.5-2 7-5"/>
                        <path d="M3 17c3 3 6 5 9 5s6-2 9-5"/>
                    </svg>
                    <span class="text-white font-bold text-xl">Plant Identifier</span>
                </a>
                <div class="flex items-center space-x-4">
                    @auth
                        <span class="text-white">{{ Auth::user()->name }}</span>
                        <form action="{{ route('logout') }}" method="POST" class="inline">
                            @csrf
                            <button type="submit" class="px-4 py-2 bg-white text-green-600 rounded-lg hover:bg-green-50 transition duration-300">
                                Logout
                            </button>
                        </form>
                    @else
                        <a href="{{ route('login') }}" class="text-white hover:text-green-100 transition duration-300">Login</a>
                        <a href="{{ route('register') }}" class="px-4 py-2 bg-white text-green-600 rounded-lg hover:bg-green-50 transition duration-300">
                            Register
                        </a>
                    @endauth
                </div>
            </div>
        </div>
    </nav>

    <div class="container mx-auto px-4 py-12">
        <div class="max-w-4xl mx-auto">
            <h1 class="text-4xl font-bold text-center text-gray-800 mb-8">Plant Identification Result</h1>
            
            <div class="bg-white rounded-xl p-8 shadow-lg">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div class="space-y-6">
                        <div class="aspect-w-4 aspect-h-3 rounded-xl overflow-hidden shadow-lg">
                            <img src="{{ $imageUrl }}" alt="Uploaded plant" class="w-full h-full object-cover transform hover:scale-105 transition duration-500">
                        </div>
                        <div class="text-center space-y-4">
                            <a href="{{ route('plants.index') }}" class="inline-flex items-center justify-center px-6 py-3 gradient-bg text-white font-semibold rounded-xl hover:opacity-90 transition duration-300 shadow-md">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6"/>
                                </svg>
                                Identify Another Plant
                            </a>
                            
                            <a href="https://plant-insights.netlify.app/" 
                               class="inline-flex items-center justify-center px-6 py-3 bg-green-100 text-green-700 font-semibold rounded-xl hover:bg-green-200 transition duration-300 shadow-md">
                                <svg class="w-5 h-5 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/>
                                </svg>
                                Learn More
                            </a>
                        </div>
                        <div class="bg-gray-50 rounded-xl p-6">
                            <h3 class="text-lg font-semibold text-gray-800 mb-3">Care Tips</h3>
                            <ul class="space-y-2 text-gray-600">
                                <li class="flex items-center">
                                    <svg class="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                    </svg>
                                    Regular watering schedule
                                </li>
                                <li class="flex items-center">
                                    <svg class="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                    </svg>
                                    Proper sunlight exposure
                                </li>
                                <li class="flex items-center">
                                    <svg class="w-5 h-5 text-green-500 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                    </svg>
                                    Optimal soil conditions
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="space-y-6">
                        @php
                            $lines = explode("\n", $plantInfo);
                            $sections = [];
                            $currentSection = null;
                            
                            foreach ($lines as $line) {
                                if (preg_match('/^\d+\.\s+(.+)$/', $line, $matches)) {
                                    $currentSection = $matches[1];
                                    $sections[$currentSection] = [];
                                } elseif (!empty(trim($line)) && $currentSection) {
                                    $sections[$currentSection][] = trim($line);
                                }
                            }
                        @endphp

                        @foreach ($sections as $title => $content)
                            <div class="bg-green-50 rounded-xl p-6">
                                <h2 class="text-2xl font-bold text-gray-800 mb-4">{{ $title }}</h2>
                                <div class="space-y-3">
                                    @foreach ($content as $line)
                                        @if (strpos($line, '-') === 0)
                                            <div class="flex items-start space-x-3">
                                                <svg class="w-5 h-5 text-green-500 mt-1 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/>
                                                </svg>
                                                <p class="text-gray-700">{{ trim(substr($line, 1)) }}</p>
                                            </div>
                                        @elseif (strpos($line, '*') === 0)
                                            <div class="flex items-start space-x-3 ml-6">
                                                <span class="w-2 h-2 rounded-full bg-green-500 mt-2 flex-shrink-0"></span>
                                                <p class="text-gray-600">{{ trim(substr($line, 1)) }}</p>
                                            </div>
                                        @else
                                            <p class="text-gray-700">{{ $line }}</p>
                                        @endif
                                    @endforeach
                                </div>
                            </div>
                        @endforeach

                        @if (isset($sections['Match Confidence']))
                            <div class="bg-gray-50 rounded-xl p-6">
                                <div class="flex items-center justify-between mb-2">
                                    <span class="text-sm font-medium text-gray-700">Confidence Score</span>
                                    @php
                                        $score = collect($sections['Match Confidence'])->first();
                                        $scoreValue = (int) filter_var($score, FILTER_SANITIZE_NUMBER_INT);
                                    @endphp
                                    <span class="text-sm font-semibold text-gray-900">{{ $scoreValue }}%</span>
                                </div>
                                <div class="w-full bg-gray-200 rounded-full h-2.5">
                                    <div class="gradient-bg h-2.5 rounded-full" style="width: {{ $scoreValue }}%"></div>
                                </div>
                                @if ($scoreValue < 80)
                                    <p class="mt-2 text-sm text-amber-600">
                                        <svg class="inline w-4 h-4 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/>
                                        </svg>
                                        Consider taking another photo for more accurate identification
                                    </p>
                                @endif
                            </div>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>