<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PlantController;
use App\Http\Controllers\AuthController;

// Authentication Routes
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login']);
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register']);
});

// Logout Route
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// Plant Routes
Route::middleware(['auth'])->group(function () {
    Route::get('/', [PlantController::class, 'index'])->name('home'); // Home route
    Route::get('/plants', [PlantController::class, 'index'])->name('plants.index'); // List plants
    Route::post('/plants/identify', [PlantController::class, 'identify'])->name('plants.identify'); // Identify plant
});
