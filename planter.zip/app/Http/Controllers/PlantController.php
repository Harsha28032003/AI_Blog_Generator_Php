<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Storage;

class PlantController extends Controller
{
    private $apiKey = '2b103bcGKLh52j5OE4bgt4n';
    private $baseUrl = 'https://my-api.plantnet.org/v2/identify/all';

    public function index()
    {
        return view('plants.index');
    }

    public function identify(Request $request)
    {
        $request->validate([
            'image' => 'required|image|max:10240', // Max 10MB
        ]);

        try {
            // Store the uploaded image
            $imagePath = $request->file('image')->store('plants', 'public');

            // Get the full path of the stored image
            $fullPath = Storage::disk('public')->path($imagePath);

            // Check if file exists
            if (!file_exists($fullPath)) {
                throw new \Exception('Image file not found');
            }

            // Create multipart form data with POST request
            $response = Http::withHeaders([
                'accept' => 'application/json',
            ])->attach(
                'images', 
                file_get_contents($fullPath),
                basename($fullPath)
            )->post($this->baseUrl . '?api-key=' . $this->apiKey);

            // Debug the response if needed
            \Log::info('PlantNet API Response:', ['response' => $response->json()]);

            if (!$response->successful()) {
                throw new \Exception('PlantNet API Error: ' . ($response->json()['message'] ?? 'Unknown error'));
            }

            $result = $response->json();

            if (!isset($result['results']) || empty($result['results'])) {
                throw new \Exception('No plant matches found');
            }

            // Get the best match (first result)
            $bestMatch = $result['results'][0];

            // Format plant information
            $plantInfo = $this->formatPlantInfo($bestMatch);
            
            // Generate the correct URL for the image
            $imageUrl = Storage::disk('public')->url($imagePath);

            return view('plants.result', compact('imageUrl', 'plantInfo'));
        } catch (\Exception $e) {
            \Log::error('Plant identification error:', [
                'message' => $e->getMessage(),
                'trace' => $e->getTraceAsString()
            ]);
            return back()->with('error', 'Error processing image: ' . $e->getMessage());
        }
        // Remove the finally block to keep the image
    }

    private function formatPlantInfo(array $match): string
    {
        $scientificName = $match['species']['scientificNameWithoutAuthor'] ?? 'Unknown';
        $commonNames = $match['species']['commonNames'] ?? ['Unknown'];
        $family = $match['species']['family']['scientificNameWithoutAuthor'] ?? 'Unknown';
        $genus = $match['species']['genus']['scientificNameWithoutAuthor'] ?? 'Unknown';
        $score = round(($match['score'] ?? 0) * 100, 2);

        return "
1. Plant Identification (Confidence: {$score}%)
   - Scientific Name: {$scientificName}
   - Common Name(s): " . implode(', ', $commonNames) . "
   - Family: {$family}
   - Genus: {$genus}

2. Plant Details
   - Scientific Classification:
     * Family: {$family}
     * Genus: {$genus}
     * Species: {$scientificName}

3. Match Confidence
   - Identification confidence score: {$score}%
   " . ($score < 80 ? "\nNote: This identification has a lower confidence score. Consider taking another photo or consulting with a plant expert for verification." : "");
    }
}