<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Plant Identifier</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <h1>Plant Identifier</h1>
        <form action="<?php echo e(route('identify')); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <label for="plant_image">Upload Plant Image:</label>
            <input type="file" name="plant_image" id="plant_image" accept="image/*" required>
            <button type="submit">Identify</button>
        </form>
        <?php if(session('error')): ?>
            <p style="color: red;"><?php echo e(session('error')); ?></p>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH D:\planter\plant-identifier\resources\views/home.blade.php ENDPATH**/ ?>