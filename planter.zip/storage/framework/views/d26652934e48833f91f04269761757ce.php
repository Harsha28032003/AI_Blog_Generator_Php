<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo e(config('app.name', 'PlantLens')); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        .upload-area {
            border: 2px dashed #e2e8f0;
            transition: all 0.3s ease;
        }
        .upload-area:hover {
            border-color: #48bb78;
        }
    </style>
</head>
<body class="bg-gray-50 min-h-screen">
    <!-- Navigation -->
    <nav class="bg-white shadow-sm">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center h-16">
                <div class="flex items-center">
                    <a href="/" class="flex items-center">
                        <span class="text-xl font-semibold text-gray-800">🌿 PlantLens</span>
                    </a>
                </div>
                <div class="flex items-center">
                    <a href="<?php echo e(route('how-it-works')); ?>" class="text-gray-600 hover:text-gray-800 px-3 py-2">How It Works</a>
                    <a href="<?php echo e(route('about')); ?>" class="text-gray-600 hover:text-gray-800 px-3 py-2">About</a>
                    <?php if(auth()->guard()->check()): ?>
                        <div class="ml-4 flex items-center">
                            <span class="text-gray-600 mr-4"><?php echo e(Auth::user()->name); ?></span>
                            <form action="<?php echo e(route('logout')); ?>" method="POST" class="inline">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                                    Logout
                                </button>
                            </form>
                        </div>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="ml-4 bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                            Get Started
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <main class="container mx-auto px-4 py-8">
        <?php if(request()->routeIs('home')): ?>
            <!-- Hero Section -->
            <div class="text-center max-w-4xl mx-auto mb-12">
                <h1 class="text-4xl font-bold text-gray-900 mb-4">Discover the World of Plants</h1>
                <p class="text-lg text-gray-600 mb-8">
                    Upload a photo of any plant and instantly learn everything about it<br>
                    using our advanced plant recognition technology.
                </p>

                <!-- Upload Section -->
                <?php if(auth()->guard()->check()): ?>
                    <form action="<?php echo e(route('plants.identify')); ?>" method="POST" enctype="multipart/form-data" class="max-w-xl mx-auto">
                        <?php echo csrf_field(); ?>
                        <div class="upload-area bg-white rounded-lg p-12 text-center">
                            <input type="file" name="image" id="image" class="hidden" accept="image/*" onchange="showPreview(event)">
                            <label for="image" class="cursor-pointer">
                                <div id="preview" class="mb-4">
                                    <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                                    </svg>
                                    <img id="preview-image" class="mx-auto hidden max-h-48 mt-4">
                                </div>
                                <p class="text-gray-600">Drag and drop your plant photo here</p>
                                <p class="text-gray-400 text-sm mt-2">or click to select a file</p>
                            </label>
                        </div>
                        <div class="mt-4 flex justify-center gap-4">
                            <button type="button" onclick="document.getElementById('image').click()" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                                Choose File
                            </button>
                            <button type="button" onclick="captureImage()" class="bg-green-600 text-white px-4 py-2 rounded-md hover:bg-green-700">
                                Use Camera
                            </button>
                        </div>
                    </form>
                <?php else: ?>
                    <div class="upload-area bg-white rounded-lg p-12 text-center">
                        <a href="<?php echo e(route('login')); ?>" class="text-gray-600">
                            <svg class="mx-auto h-12 w-12 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"></path>
                            </svg>
                            <p class="text-gray-600 mt-4">Sign in to start identifying plants</p>
                        </a>
                    </div>
                <?php endif; ?>
            </div>

            <!-- How It Works Section -->
            <div class="max-w-5xl mx-auto py-12">
                <h2 class="text-3xl font-bold text-center text-gray-900 mb-12">How It Works</h2>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div class="text-center">
                        <div class="bg-green-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                            <svg class="h-8 w-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path>
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path>
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold mb-2">Upload Photo</h3>
                        <p class="text-gray-600">Take a photo or upload an existing image of any plant you'd like to identify.</p>
                    </div>
                    <div class="text-center">
                        <div class="bg-green-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                            <svg class="h-8 w-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"></path>
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold mb-2">AI Analysis</h3>
                        <p class="text-gray-600">Our advanced plant recognition system analyzes the image in seconds.</p>
                    </div>
                    <div class="text-center">
                        <div class="bg-green-100 rounded-full p-4 w-16 h-16 mx-auto mb-4 flex items-center justify-center">
                            <svg class="h-8 w-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path>
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold mb-2">Get Results</h3>
                        <p class="text-gray-600">Receive detailed information about your plant, including care instructions.</p>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <?php echo $__env->yieldContent('content'); ?>
        <?php endif; ?>
    </main>

    <!-- Footer -->
    <footer class="bg-white border-t mt-12">
        <div class="container mx-auto px-4 py-8">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
                <div>
                    <h3 class="font-semibold text-gray-900 mb-4">PlantLens</h3>
                    <p class="text-gray-600 text-sm">
                        Identify and learn about any plant instantly using our advanced AI-powered recognition system.
                    </p>
                </div>
                <div>
                    <h3 class="font-semibold text-gray-900 mb-4">Quick Links</h3>
                    <ul class="space-y-2">
                        <li><a href="<?php echo e(route('about')); ?>" class="text-gray-600 hover:text-gray-900">About Us</a></li>
                        <li><a href="<?php echo e(route('privacy')); ?>" class="text-gray-600 hover:text-gray-900">Privacy Policy</a></li>
                        <li><a href="<?php echo e(route('terms')); ?>" class="text-gray-600 hover:text-gray-900">Terms of Service</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="font-semibold text-gray-900 mb-4">Contact</h3>
                    <ul class="space-y-2">
                        <li><a href="#" class="text-gray-600 hover:text-gray-900">Support</a></li>
                        <li><a href="#" class="text-gray-600 hover:text-gray-900">Contact Us</a></li>
                    </ul>
                </div>
                <div>
                    <h3 class="font-semibold text-gray-900 mb-4">Follow Us</h3>
                    <div class="flex space-x-4">
                        <a href="#" class="text-gray-400 hover:text-gray-900">
                            <span class="sr-only">Twitter</span>
                            <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M8.29 20.251c7.547 0 11.675-6.253 11.675-11.675 0-.178 0-.355-.012-.53A8.348 8.348 0 0022 5.92a8.19 8.19 0 01-2.357.646 4.118 4.118 0 001.804-2.27 8.224 8.224 0 01-2.605.996 4.107 4.107 0 00-6.993 3.743 11.65 11.65 0 01-8.457-4.287 4.106 4.106 0 001.27 5.477A4.072 4.072 0 012.8 9.713v.052a4.105 4.105 0 003.292 4.022 4.095 4.095 0 01-1.853.07 4.108 4.108 0 003.834 2.85A8.233 8.233 0 012 18.407a11.616 11.616 0 006.29 1.84"></path>
                            </svg>
                        </a>
                        <a href="#" class="text-gray-400 hover:text-gray-900">
                            <span class="sr-only">GitHub</span>
                            <svg class="h-6 w-6" fill="currentColor" viewBox="0 0 24 24">
                                <path fill-rule="evenodd" d="M12 2C6.477 2 2 6.484 2 12.017c0 4.425 2.865 8.18 6.839 9.504.5.092.682-.217.682-.483 0-.237-.008-.868-.013-1.703-2.782.605-3.369-1.343-3.369-1.343-.454-1.158-1.11-1.466-1.11-1.466-.908-.62.069-.608.069-.608 1.003.07 1.531 1.032 1.531 1.032.892 1.53 2.341 1.088 2.91.832.092-.647.35-1.088.636-1.3381.016 2.88.62C11.07 16.517 11 15.887 11 15.4c-4.418-.5-9.066-2.206-9.066-9.82 0-2.17.775-3.945 2.046-5.337-.205-.504-.89-2.525.195-5.263 0 0 1.67-.534 5.466 2.037A18.915 18.915 0 0112 5.42c1.27.01 2.555.17 3.755.5 3.794-2.57 5.464-2.037 5.464-2.037 1.087 2.738.402 4.76.197 5.263 1.273 1.392 2.046 3.167 2.046 5.337 0 7.634-4.654 9.312-9.088 9.8.72.62 1.358 1.842 1.358 3.712 0 2.678-.024 4.838-.024 5.496 0 .268.18.58.688.482C19.138 20.197 22 16.44 22 12.017 22 6.484 17.522 2 12 2z" clip-rule="evenodd"></path>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <div class="mt-8 border-t pt-8 text-center">
                <p class="text-gray-400 text-sm">
                    © <?php echo e(date('Y')); ?> PlantLens. All rights reserved.
                </p>
            </div>
        </div>
    </footer>

    <!-- Scripts -->
    <script>
        function showPreview(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                const previewImage = document.getElementById('preview-image');
                const previewIcon = document.querySelector('#preview svg');
                const previewText = document.querySelector('#preview + p');
                
                reader.onload = function(e) {
                    previewImage.src = e.target.result;
                    previewImage.classList.remove('hidden');
                    previewIcon.classList.add('hidden');
                    if (previewText) {
                        previewText.classList.add('hidden');
                    }
                }
                
                reader.readAsDataURL(file);
                
                // Auto-submit the form when file is selected
                document.querySelector('form').submit();
            }
        }

        function captureImage() {
            const input = document.getElementById('image');
            input.setAttribute('capture', 'environment');
            input.click();
        }

        // Drag and drop functionality
        const dropArea = document.querySelector('.upload-area');
        
        if (dropArea) {
            ['dragenter', 'dragover', 'dragleave', 'drop'].forEach(eventName => {
                dropArea.addEventListener(eventName, preventDefaults, false);
            });

            function preventDefaults(e) {
                e.preventDefault();
                e.stopPropagation();
            }

            ['dragenter', 'dragover'].forEach(eventName => {
                dropArea.addEventListener(eventName, highlight, false);
            });

            ['dragleave', 'drop'].forEach(eventName => {
                dropArea.addEventListener(eventName, unhighlight, false);
            });

            function highlight(e) {
                dropArea.classList.add('border-green-500');
            }

            function unhighlight(e) {
                dropArea.classList.remove('border-green-500');
            }

            dropArea.addEventListener('drop', handleDrop, false);

            function handleDrop(e) {
                const dt = e.dataTransfer;
                const files = dt.files;
                const input = document.getElementById('image');
                
                input.files = files;
                showPreview({ target: input });
            }
        }
    </script>

    <?php if(session('error')): ?>
        <div class="fixed bottom-4 right-4 bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded max-w-md" role="alert">
            <strong class="font-bold">Error!</strong>
            <span class="block sm:inline"><?php echo e(session('error')); ?></span>
        </div>
    <?php endif; ?>
</body>
</html><?php /**PATH D:\planter\plant-identifier\resources\views/layouts/app.blade.php ENDPATH**/ ?>